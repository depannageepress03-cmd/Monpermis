// QA E2E — apprenant : parcours code (QCM) + examen blanc complet.
import { expect, test } from '@playwright/test'

async function login(page) {
  await page.goto('/connexion')
  await page.getByLabel('E-mail', { exact: true }).fill('e2e@test.local')
  await page.getByLabel('Mot de passe', { exact: true }).fill('E2eTest1234')
  await page.getByRole('button', { name: 'Se connecter' }).click()
  await page.waitForURL('**/accueil**', { timeout: 20000 })
}

test('QCM : réponse juste puis fausse, verdict affiché', async ({ page }) => {
  await login(page)
  await page.goto('/code-de-la-route/revision-chapitres')
  // Premier chapitre : ouvre les questions.
  await page.getByRole('link', { name: /Ouvrir le chapitre/ }).first().click()
  await expect(page).toHaveURL(/questions/, { timeout: 20000 })

  // Répond à la première question (premier choix), valide.
  const options = page.locator('button').filter({ hasText: /^[A-D]\b|^.+/ }).first()
  await options.first().click()
  await page.getByRole('button', { name: /Valider/i }).click()
  await expect(page.getByText(/Bonne réponse|Pas tout à fait/i)).toBeVisible({
    timeout: 20000,
  })
})

test('examen blanc complet : 20 questions puis score', async ({ page }) => {
  await login(page)
  await page.goto('/code-de-la-route/examens-test')
  // Démarre le premier examen (carte cliquable).
  const cards = page.locator('div[role="button"], button').filter({ hasText: /Examen|N°|01/ })
  await cards.first().click({ timeout: 20000 }).catch(() => {})
  // Si la carte n'est pas cliquable directement, navigue à l'URL directe.
  if (!/\/examens-test\/\d+/.test(page.url())) {
    await page.goto('/code-de-la-route/examens-test/1')
  }
  await expect(page.getByText(/Examen blanc n°1/)).toBeVisible({ timeout: 30000 })

  for (let i = 0; i < 20; i += 1) {
    // Sélectionne la première option disponible.
    const option = page.locator('main button, form button').filter({ hasNotText: /Valider|suivante|Terminer|Quitter/i }).first()
    await option.click({ timeout: 15000 })
    await page.getByRole('button', { name: /Valider ma réponse/ }).click()
    const next = page.getByRole('button', { name: /Question suivante|Terminer|Voir mon score/i })
    await next.click({ timeout: 15000 })
  }
  // Écran de fin : score affiché.
  await expect(page.getByText(/\/20|Score|Résultat|Terminé|félicitations/i).first()).toBeVisible({
    timeout: 30000,
  })
})
